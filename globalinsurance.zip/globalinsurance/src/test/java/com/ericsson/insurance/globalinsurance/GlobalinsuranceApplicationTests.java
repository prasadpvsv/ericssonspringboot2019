package com.ericsson.insurance.globalinsurance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalinsuranceApplicationTests {

	@Test
	void contextLoads() {
	}

}
