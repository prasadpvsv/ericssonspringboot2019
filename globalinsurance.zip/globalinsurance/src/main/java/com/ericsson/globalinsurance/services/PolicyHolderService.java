package com.ericsson.globalinsurance.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.globalinsurance.models.PolicyHolder;
import com.ericsson.globalinsurance.models.Vehicle;
import com.ericsson.globalinsurance.repositories.PolicyHolderRepository;


@Service
public class PolicyHolderService {
	@Autowired
	private PolicyHolderRepository repo;
    
    private boolean status;
    //insert query
    
    public PolicyHolder savePolicyHolder(PolicyHolder policyHolder)
    {
    	return repo.save(policyHolder);
    }
    
    //select all
    
    public List<PolicyHolder> getAllPolicyHolders()
    {
    	return repo.findAll();
    }
    
    //select by adharcard no
    
    public PolicyHolder getPolicyHolderById(long adharCardNo)
    {
    	return repo.findById(adharCardNo).orElse(null);
    }
    
    //delete query
    
    public boolean deletePolicyHolderById(long adharCardNo)
    {
    	repo.deleteById(adharCardNo);
    	status=true;
    	return status;
    	
    }
    
}
