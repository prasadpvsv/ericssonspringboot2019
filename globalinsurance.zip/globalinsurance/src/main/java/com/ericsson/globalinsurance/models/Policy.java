package com.ericsson.globalinsurance.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

@Entity
@Table(name="Policy")
public class Policy {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PolicyNo")
	private long policyNo;
	@Column(name="Type",nullable=false,length=50)
	private String type;
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy-MMM-dd",shape=Shape.STRING)
	@Column(name="FromDate")
	private Date fromDate;
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy-MMM-dd",shape=Shape.STRING)
	@Column(name="ToDate")
	private Date toDate;
	@Column(name="InsuredSum")
	private long insuredSum;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="VehicleId")
	private Vehicle vehicle;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SSN")
	private PolicyHolder owner;	
	
	
	public Vehicle getVehicle() {
		return vehicle;
	}
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public long getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(long policyNo) {
		this.policyNo = policyNo;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public long getInsuredSum() {
		return insuredSum;
	}
	public void setInsuredSum(long insuredSum) {
		this.insuredSum = insuredSum;
	}
	
	public PolicyHolder getOwner() {
		return owner;
	}
	public void setOwner(PolicyHolder owner) {
		this.owner = owner;
	}
	
	
	
	
	
	
}
