package com.ericsson.globalinsurance.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.globalinsurance.models.Vehicle;
import com.ericsson.globalinsurance.repositories.VehicleRepository;

@Service
public class VehicleService {
    @Autowired
	private VehicleRepository repo;
    
    private boolean status;
    //insert query
    
    public Vehicle saveVehicle(Vehicle vehicle)
    {
    	return repo.save(vehicle);
    }
    
    //select all
    
    public List<Vehicle> getAllVehicles()
    {
    	return repo.findAll();
    }
    
    //select by engine no
    
    public Vehicle getVehicleById(long engineNo)
    {
    	return repo.findById(engineNo).orElse(null);
    }
    
    //delete query
    
    public boolean deleteVehicleById(long engineNo)
    {
    	repo.deleteById(engineNo);
    	status=true;
    	return status;
    	
    }
    
    
    
    
}
