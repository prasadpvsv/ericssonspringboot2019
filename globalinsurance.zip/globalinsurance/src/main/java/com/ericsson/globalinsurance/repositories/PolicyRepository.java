package com.ericsson.globalinsurance.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ericsson.globalinsurance.models.Policy;

public interface PolicyRepository extends JpaRepository<Policy,Long>{

}
