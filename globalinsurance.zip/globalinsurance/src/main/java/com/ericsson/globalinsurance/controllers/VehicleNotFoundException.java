package com.ericsson.globalinsurance.controllers;

public class VehicleNotFoundException extends Exception {

	

	public VehicleNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
