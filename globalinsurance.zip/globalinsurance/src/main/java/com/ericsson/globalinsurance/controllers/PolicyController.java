package com.ericsson.globalinsurance.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ericsson.globalinsurance.models.Policy;
import com.ericsson.globalinsurance.models.PolicyHolder;
import com.ericsson.globalinsurance.services.PolicyHolderService;
import com.ericsson.globalinsurance.services.PolicyService;

@RestController
public class PolicyController {

	@Autowired
	private PolicyService policyService;
	
	@CrossOrigin("*")
	@PostMapping("/addPolicy/{engineNo}/{cardNo}")
	public @ResponseBody Policy addPolicy(@RequestBody Policy policy,@PathVariable("engineNo") long engineNo,
			@PathVariable("cardNo") long cardNo)
	{
		return policyService.savePolicy(policy,engineNo,cardNo);
	}
	@CrossOrigin("*")
	@GetMapping("/getallPolicies")
	public List<Policy> getAllPolicyHolders()
	{
		return policyService.getAllPolicies();
	}
	@CrossOrigin("*")
	@GetMapping("/getPolicybyid/{policyNo}")
	public Policy getPolicyHolderById(@PathVariable("policyNo") long policyNo)
	{
		return policyService.getPolicyById(policyNo);
	}
	
}
