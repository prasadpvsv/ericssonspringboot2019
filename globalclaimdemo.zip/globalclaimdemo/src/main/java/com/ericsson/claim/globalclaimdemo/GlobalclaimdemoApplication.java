package com.ericsson.claim.globalclaimdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@ComponentScan(basePackages="com.ericsson.claim")
@EntityScan(basePackages="com.ericsson.claim")
@EnableMongoRepositories(basePackages="com.ericsson.claim")
public class GlobalclaimdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalclaimdemoApplication.class, args);
	}

}
