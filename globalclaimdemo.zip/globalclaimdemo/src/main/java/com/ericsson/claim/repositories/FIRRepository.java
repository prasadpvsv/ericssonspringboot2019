package com.ericsson.claim.repositories;



import org.springframework.data.mongodb.repository.MongoRepository;

import com.ericsson.claim.models.FIR;

public interface FIRRepository extends MongoRepository<FIR,Long>{

}
