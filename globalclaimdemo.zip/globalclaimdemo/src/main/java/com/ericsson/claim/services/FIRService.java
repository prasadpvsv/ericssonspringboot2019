package com.ericsson.claim.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ericsson.claim.models.FIR;
import com.ericsson.claim.repositories.FIRRepository;


@Service
public class FIRService {
    @Autowired
	private FIRRepository repo;
    boolean status;
    //insert query
    
    public FIR saveFIR(FIR fir)
    {
    	return repo.save(fir);
    }
    
    //select all

    public List<FIR> getAllFIRS()
    {
    	return repo.findAll();
    }
    
    //select by engine no
    
    public FIR getFIRById(long firNo)
    {
    	return repo.findById(firNo).orElse(null);
    }
    
    //delete query
    
    public boolean deleteFIRById(long firNo)
    {
    	repo.deleteById(firNo);
    	status=true;
    	return status;
    	
    }
    
	
}
