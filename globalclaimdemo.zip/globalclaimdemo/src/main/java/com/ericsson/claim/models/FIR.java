package com.ericsson.claim.models;

import java.util.Date;

import org.bson.codecs.pojo.annotations.BsonId;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

@Document(collection="FIRS")
public class FIR {
	@BsonId
	private long firNo;
	private String description;
	
	private String firDate;
	public String getFirDate() {
		return firDate;
	}
	public void setFirDate(String firDate) {
		this.firDate = firDate;
	}
	private String location;
	public long getFirNo() {
		return firNo;
	}
	public void setFirNo(long firNo) {
		this.firNo = firNo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	

}
