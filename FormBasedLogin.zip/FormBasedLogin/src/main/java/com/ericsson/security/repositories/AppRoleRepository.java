package com.ericsson.security.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ericsson.security.models.AppRole;

public interface AppRoleRepository extends JpaRepository<AppRole,Integer>{

}
