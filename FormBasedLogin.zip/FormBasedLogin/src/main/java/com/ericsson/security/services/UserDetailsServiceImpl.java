package com.ericsson.security.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ericsson.security.models.AppRole;
import com.ericsson.security.models.AppUser;
import com.ericsson.security.repositories.AppRoleRepository;
import com.ericsson.security.repositories.AppUserRepository;
@Service
public class UserDetailsServiceImpl implements UserDetailsService {
 
    @Autowired
    private AppUserRepository appUserRepo;
 
    @Autowired
    private AppRoleRepository appRoleRepo;
 
    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        AppUser appUser = this.appUserRepo.findByName(userName);
 
        if (appUser == null) {
            System.out.println("User not found! " + userName);
            throw new UsernameNotFoundException("User " + userName + " was not found in the database");
        }
 
        System.out.println("Found User: " + appUser);
 
        // [ROLE_USER, ROLE_ADMIN,..]
        AppRole role = appRoleRepo.findById(appUser.getAppRole().getRoleId()).orElse(null);
        System.out.println("Found Role: " + appUser.getAppRole().getRoleId());
        System.out.println("Found Role: " + role);
        List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
        if (role.getRoleName() != null) {
            //for (String role : roleNames) {
                // ROLE_USER, ROLE_ADMIN,..
                GrantedAuthority authority = new SimpleGrantedAuthority(role.getRoleName());
                grantList.add(authority);
            //}
        }
 
        UserDetails userDetails = (UserDetails) new User(appUser.getUserName(), //
                appUser.getEncrytedPassword(), grantList);
 
        return userDetails;
    }
 
}
