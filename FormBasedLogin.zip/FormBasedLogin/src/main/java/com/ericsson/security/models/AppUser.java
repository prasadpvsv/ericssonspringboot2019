package com.ericsson.security.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="AppUser")
public class AppUser {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="UserId")
	 private Long userId;
	@Column(name="UserName",nullable=false,length=50)
	 private String userName;
	@Column(name="EncrytedPassword",nullable=false,length=150)
	 private String encrytedPassword;
	
	@OneToOne(fetch=FetchType.LAZY,optional=false)
	@JoinColumn(name="RoleId")
	private AppRole appRole;
	 
	    public AppRole getAppRole() {
		return appRole;
	}

	public void setAppRole(AppRole appRole) {
		this.appRole = appRole;
	}

		public Long getUserId() {
	        return userId;
	    }
	 
	    public void setUserId(Long userId) {
	        this.userId = userId;
	    }
	 
	    public String getUserName() {
	        return userName;
	    }
	 
	    public void setUserName(String userName) {
	        this.userName = userName;
	    }
	 
	    public String getEncrytedPassword() {
	        return encrytedPassword;
	    }
	 
	    public void setEncrytedPassword(String encrytedPassword) {
	        this.encrytedPassword = encrytedPassword;
	    }
	 
	    
}
