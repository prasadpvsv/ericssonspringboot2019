package com.ericsson.security.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ericsson.security.models.AppUser;

public interface AppUserRepository extends JpaRepository<AppUser,Long>{

	//JPA refers class and fields not table
		@Query("select appuser from AppUser appuser where appuser.userName=:name")
		public AppUser findByName(@Param("name") String name);

	
}
