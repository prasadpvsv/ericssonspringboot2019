package com.ericsson.security.FormBasedLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormBasedLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
